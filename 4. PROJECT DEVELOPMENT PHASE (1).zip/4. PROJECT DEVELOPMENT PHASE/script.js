<script>
        document.getElementById('prolonged_declarations').addEventListener('click', function() {
            alert('Prolonged Declarations feature clicked');
        });

        document.getElementById('histogram_variance').addEventListener('click', function() {
            
            alert('Histogram Variance feature clicked');
        });

        document.getElementById('histogram_mode').addEventListener('click', function() {
            alert('Histogram Mode feature clicked');
        });

        document.getElementById('accelerations').addEventListener('click', function() {
            // Add logic for accelerations feature
            alert('Accelerations feature clicked');
        });
    </script>
